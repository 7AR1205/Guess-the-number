import tkinter as tk
import random
import json
import os

CONFIG_FILE = "config.json"
BEST_SCORE_FILE = "best_score.json"
DEFAULT_MAX_GUESS = 100

def load_config():
    if not os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "w") as f:
            json.dump({"max_guess": DEFAULT_MAX_GUESS}, f)
    with open(CONFIG_FILE, "r") as f:
        return json.load(f)

def load_best_score():
    if not os.path.exists(BEST_SCORE_FILE):
        with open(BEST_SCORE_FILE, "w") as f:
            json.dump({"best_score": None}, f)
    with open(BEST_SCORE_FILE, "r") as f:
        return json.load(f).get("best_score")

def save_best_score(score):
    with open(BEST_SCORE_FILE, "w") as f:
        json.dump({"best_score": score}, f)

class GuessNumberGame(tk.Tk):
    TEASES_CONTRADICTION = [
        "Can you even read English?",
        "Seriously? That makes no sense!",
        "Oops, try paying attention!",
        "Are you guessing backwards on purpose?",
        "Reading comprehension... try it sometime.",
        "Nope, that’s not how this works.",
        "You lost me there. Try again!",
        "Hint: follow the clues, genius.",
        "Your logic is... questionable.",
        "Try again, smarty pants!"
    ]

    TEASES_WORSE_ATTEMPT = [
        "I thought you were good at this game...",
        "Well, that was disappointing...",
        "Oof, your skills slipped there!",
        "Did you just give up?",
        "Better luck next time, champ!",
        "Trying to break your own record, huh?",
        "Slowing down already? Come on!",
        "Is the pressure getting to you?",
        "You can do better than that!",
        "At least you’re consistent... sort of."
    ]

    ERROR_MESSAGES = [
        "Invalid input! Enter a valid number.",
        "Oops! That’s not a number.",
        "Numbers only, please!",
        "Try typing a number this time.",
        "Not a number, try again!",
        "Input error: numbers are your friends.",
        "Please enter an integer, not a letter.",
        "Numbers > letters in this game.",
        "Enter a number, pretty please.",
        "Your keyboard has numbers, right?"
    ]

    RANGE_ERROR_MESSAGES = [
        "Out of range! Stay between 0 and {max}.",
        "Keep it between 0 and {max}, please.",
        "That number’s too big or too small!",
        "Guess a number in the valid range.",
        "Try a number from 0 to {max}.",
        "That’s beyond the limits, try again!",
        "Oops, number not in range!",
        "Focus! It’s between 0 and {max}.",
        "Guess within range, friend!",
        "Range is key here: 0 to {max}."
    ]

    def __init__(self):
        super().__init__()

        self.config_data = load_config()
        self.max_guess = self.config_data.get("max_guess", DEFAULT_MAX_GUESS)
        self.best_score = load_best_score()

        self.attempts = 0
        self.number = random.randint(0, self.max_guess)
        self.last_hint = None
        self.last_guess = None

        self.attributes("-fullscreen", True)
        self.configure(bg="black")

        font_main = ("Consolas", 24)
        font_button = ("Consolas", 18)
        font_feedback = ("Consolas", 20)
        font_error = ("Consolas", 18)

        self.label_instruction = tk.Label(self, text=f"Guess the number between 0 and {self.max_guess}",
                                          fg="white", bg="black", font=font_main)
        self.label_instruction.pack(pady=30)

        self.label_attempts = tk.Label(self, text="Attempts: 0", fg="white", bg="black", font=font_error)
        self.label_attempts.pack(pady=10)

        self.entry_guess = tk.Entry(self, font=font_main, justify="center")
        self.entry_guess.pack()
        self.entry_guess.focus()

        self.button_submit = tk.Button(self, text="Submit Guess", command=self.check_guess,
                                       fg="white", bg="#222", font=font_button, activebackground="#555")
        self.button_submit.pack(pady=15)

        self.label_error = tk.Label(self, text="", fg="red", bg="black", font=font_error)
        self.label_error.pack()

        self.label_feedback = tk.Label(self, text="", fg="white", bg="black", font=font_feedback)
        self.label_feedback.pack(pady=15)

        self.label_best_score = tk.Label(self, text=self.get_best_score_text(),
                                         fg="white", bg="black", font=font_error)
        self.label_best_score.pack(pady=20)

        self.button_restart = tk.Button(self, text="Restart Game", command=self.restart_game,
                                        fg="white", bg="#222", font=font_button, activebackground="#555")
        self.button_restart.pack(pady=10)

        self.bind("<Escape>", lambda e: self.destroy())

    def get_best_score_text(self):
        return f"Best Score: {self.best_score} attempts" if self.best_score is not None else "No best score yet."

    def check_guess(self):
        guess_str = self.entry_guess.get()
        self.label_error.config(text="")  # clear error messages

        if not guess_str.isdigit():
            tease = random.choice(self.ERROR_MESSAGES)
            self.label_error.config(text=tease)
            self.entry_guess.delete(0, tk.END)
            return

        guess = int(guess_str)
        if guess < 0 or guess > self.max_guess:
            tease = random.choice(self.RANGE_ERROR_MESSAGES).format(max=self.max_guess)
            self.label_error.config(text=tease)
            self.entry_guess.delete(0, tk.END)
            return

        self.attempts += 1
        self.label_attempts.config(text=f"Attempts: {self.attempts}")

        # Contradiction tease
        if self.last_hint and self.last_guess is not None:
            if self.last_hint == "lower" and guess > self.last_guess:
                tease = random.choice(self.TEASES_CONTRADICTION)
                self.label_feedback.config(text=tease)
                self.entry_guess.delete(0, tk.END)
                return
            if self.last_hint == "higher" and guess < self.last_guess:
                tease = random.choice(self.TEASES_CONTRADICTION)
                self.label_feedback.config(text=tease)
                self.entry_guess.delete(0, tk.END)
                return

        if guess == self.number:
            msg = f"🎉 Correct! You guessed it in {self.attempts} attempts."
            if self.best_score is not None and self.attempts > self.best_score:
                msg += " " + random.choice(self.TEASES_WORSE_ATTEMPT)

            self.label_feedback.config(text=msg)

            if self.best_score is None or self.attempts < self.best_score:
                self.best_score = self.attempts
                save_best_score(self.best_score)
                self.label_best_score.config(text=self.get_best_score_text())

            self.button_submit.config(state=tk.DISABLED)
            self.last_hint = None
            self.last_guess = None
        elif guess < self.number:
            self.label_feedback.config(text="Guess higher!")
            self.last_hint = "higher"
            self.last_guess = guess
        else:
            self.label_feedback.config(text="Guess lower!")
            self.last_hint = "lower"
            self.last_guess = guess

        self.entry_guess.delete(0, tk.END)

    def restart_game(self):
        self.attempts = 0
        self.number = random.randint(0, self.max_guess)
        self.last_hint = None
        self.last_guess = None
        self.label_feedback.config(text="")
        self.label_error.config(text="")
        self.label_attempts.config(text="Attempts: 0")
        self.entry_guess.delete(0, tk.END)
        self.button_submit.config(state=tk.NORMAL)
        self.entry_guess.focus()

if __name__ == "__main__":
    app = GuessNumberGame()
    app.mainloop()
